#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_wallerpaper.h"

class wallerpaper : public QMainWindow
{
    Q_OBJECT

public:
    wallerpaper(QWidget *parent = Q_NULLPTR);
    int choose();
public slots:
    void  pushbutton();
  
private:
    Ui::wallerpaperClass ui;
};

